![Metafacture](https://raw.github.com/wiki/culturegraph/metafacture-core/img/metafacture.png)

metafacture-core
================

Metafacture is a toolkit for processing semi-structured data with a focus on library metadata. It provides tools for reading, writing and transforming data. Metafacture can be used as a stand-alone application or as a java library.

See the wiki for more information: https://github.com/culturegraph/metafacture-core/wiki<br />
For support and discussion join the mailing list: http://lists.dnb.de/mailman/listinfo/metafacture
